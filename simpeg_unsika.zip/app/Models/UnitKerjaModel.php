<?php

namespace App\Models;

use CodeIgniter\Model;

class UnitKerjaModel extends Model
{
    protected $table = 'tbl_unit_kerja';
    protected $useTimestamps = true;
}
